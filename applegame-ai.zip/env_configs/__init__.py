from .sac_config import sac_config

configs = {
    "sac": sac_config,
}
