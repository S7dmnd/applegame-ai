# 사용자의 화면 스크린샷 (py auto gui? 그거)
# 게임 화면만 auto cropping
# CNN 모델 불러오기, Differentiator instantiation
# Differentiator에게 autocropped된 화면 넘기기
# 2D Grid 출력
# Learner에게 2D Grid 넘기기

